import xml.etree.ElementTree as ET
import re
import json

# Parse shared strings
tree = ET.parse('extracted/xl/sharedStrings.xml')
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
root = tree.getroot()
shared_strings = []
for si in root.findall('.//s:si', ns):
    texts = []
    for t in si.findall('.//s:t', ns):
        if t.text:
            texts.append(t.text)
    shared_strings.append(''.join(texts))

# Parse sheet1
tree2 = ET.parse('extracted/xl/worksheets/sheet1.xml')
ns2 = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
root2 = tree2.getroot()

# Extract ROM words (I column)
rom_words = []
for row in root2.findall('.//s:row', ns2):
    r = int(row.get('r'))
    if r >= 2:
        for c in row.findall('s:c', ns2):
            cell_ref = c.get('r')
            if cell_ref and cell_ref[0] == 'I':
                v = c.find('s:v', ns2)
                if v is not None and v.text:
                    # Check if it's a shared string reference
                    t = c.get('t', '')
                    if t == 's':
                        idx = int(v.text)
                        hex_str = shared_strings[idx]
                        # Clean and pad
                        hex_str = hex_str.strip()
                        # Some values may be > 32-bit (e.g., "13B491E0C" which is 9 hex chars = 36 bits)
                        # Store as-is
                        rom_words.append((r, hex_str))

print(f"Extracted {len(rom_words)} ROM words")
print("First 10:")
for i, (row, val) in enumerate(rom_words[:10]):
    print(f"  [{i}] row={row}: {val}")

# Also extract K column data (initial memory)
k_data = {}
for row in root2.findall('.//s:row', ns2):
    r = int(row.get('r'))
    for c in row.findall('s:c', ns2):
        cell_ref = c.get('r')
        if cell_ref and cell_ref[0] == 'K':
            v = c.find('s:v', ns2)
            if v is not None and v.text:
                t = c.get('t', '')
                val = v.text
                if t == 's':
                    idx = int(val)
                    val = shared_strings[idx]
                k_data[r] = val

# Save ROM words as raw hex strings
with open('rom_raw.txt', 'w') as f:
    for row, val in rom_words:
        f.write(f"{row}: {val}\n")

# Save the ROM words in machine-readable format
with open('rom_words.txt', 'w') as f:
    for row, val in rom_words:
        # Convert hex string to integer
        try:
            ival = int(val, 16)
            f.write(f"{ival}\n")
        except:
            f.write(f"0  # failed to parse: {val}\n")

# Save K column data
with open('k_data.txt', 'w') as f:
    for r in sorted(k_data.keys()):
        val = k_data[r]
        try:
            ival = int(str(val), 16)
            f.write(f"{r}: {ival}\n")
        except:
            f.write(f"{r}: {val}  # not hex\n")

print(f"\nK column entries: {len(k_data)}")
