import xml.etree.ElementTree as ET
import re, json, os

exdir = "/run/media/luna/数据和游戏/Codes/Python/ElfCTF/workspace/extracted"

# Parse shared strings
tree = ET.parse(f"{exdir}/xl/sharedStrings.xml")
ns = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
ss = []
for si in tree.findall(".//s:si", ns):
    texts = []
    for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t"):
        if t.text: texts.append(t.text)
    ss.append("".join(texts))
print(f"Total shared strings: {len(ss)}")

# Parse sheet1 XML
tree = ET.parse(f"{exdir}/xl/worksheets/sheet1.xml")
root = tree.getroot()

# Extract all I column values (ROM)
cells = {}
for row in root.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row"):
    r = int(row.get("r"))
    for c in row:
        ref = c.get("r")
        if ref is None: continue
        col = ref[0]  # A, B, C, etc.
        row_num = int(re.findall(r'\d+', ref)[0])
        
        val = None
        formula = None
        t = c.get("t", "")
        v = c.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v")
        f = c.find("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}f")
        
        if f is not None and f.text:
            formula = f.text
        if t == "s" and v is not None and v.text:
            idx = int(v.text)
            if 0 <= idx < len(ss):
                val = ss[idx]
        elif t == "str" and v is not None and v.text:
            val = v.text
        elif t in ("", "n", "b") and v is not None and v.text:
            try: val = int(v.text)
            except: 
                try: val = float(v.text)
                except: val = v.text
        
        cells[(col, row_num)] = {"val": val, "formula": formula}

# Extract ROM words from I column (rows 2-2276)
rom_words = []
for r in range(2, 2277):
    key = ("I", r)
    if key in cells and cells[key]["val"] is not None:
        s = str(cells[key]["val"])
        rom_words.append(s)
        
print(f"\nNumber of ROM words: {len(rom_words)}")
print("\nFirst 20 ROM words:")
for i, w in enumerate(rom_words[:20]):
    print(f"  [{i}] {w}")

# Now let's also look at the instruction decode formulas
# Key cells from C column
formula_keys = [("C", i) for i in range(4, 111)]
print("\n\nInstruction decode pipeline (C-column formulas):")
for k in formula_keys:
    if k in cells and cells[k].get("formula"):
        print(f"  {k[0]}{k[1]}: {cells[k]['formula']}")
    elif k in cells and cells[k].get("val") is not None:
        print(f"  {k[0]}{k[1]}: VALUE={cells[k]['val']}")

# Extract opcode types from C15:C23
print("\n\nOpcode detection (C15:C23):")
for r in range(15, 24):
    k = ("C", r)
    if k in cells and cells[k].get("formula"):
        print(f"  {k[0]}{k[1]}: {cells[k]['formula']}")

# Look at the J column (registers)
print("\n\nJ column (register file) initial values:")
for r in range(2, 34):
    k = ("J", r)
    if k in cells:
        v = cells[k].get("val")
        f = cells[k].get("formula", "")
        if v is not None or f:
            print(f"  J{r}: val={v}, formula={f}")

# Look at F column (output)
print("\n\nF column (output related):")
for r in range(1, 20):
    k = ("F", r)
    if k in cells:
        v = cells[k].get("val")
        f = cells[k].get("formula", "")
        if v is not None or f:
            print(f"  F{r}: val={v}, formula={f}")

# The key F10 is the output string
k = ("F", 10)
if k in cells:
    print(f"\nF10: val={cells[k].get('val')}, formula={cells[k].get('formula')}")

# C109 = CHAR output
k = ("C", 109)
if k in cells:
    print(f"C109: val={cells[k].get('val')}, formula={cells[k].get('formula')}")

# C74 = halt condition (PC = 268435456)
k = ("C", 74)
if k in cells:
    print(f"C74: val={cells[k].get('val')}, formula={cells[k].get('formula')}")
print(f"C74 formula: {cells.get(('C',74),{}).get('formula','N/A')}")

# B2 = execution control
print(f"\nB2: val={cells.get(('B',2),{}).get('val','N/A')}, formula={cells.get(('B',2),{}).get('formula','N/A')}")

# Save ROM words
with open("/run/media/luna/数据和游戏/Codes/Python/ElfCTF/workspace/rom_words.txt", "w") as f:
    for w in rom_words:
        f.write(w + "\n")
print(f"\nSaved {len(rom_words)} ROM words to rom_words.txt")

